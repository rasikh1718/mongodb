'''Write a program to accept ID and new salary of the worker. Update 
the document with new salary. Display the document after updation'''

import json
from typing import Set
from matplotlib import collections
id=int(input('Enter id :'))
nwsal=int(input("Enter the new salary : "))
worker={"_id":id}

newsalary= {"salary":nwsal}


file=open("worker.json","w")
json.dump(worker,file)

from pymongo import MongoClient

constr="mongodb+srv://RasikhDB:Rasikh1718*@rasikhdb.x9rflrb.mongodb.net/?retryWrites=true&w=majority"

client=MongoClient(constr)

db=client["office"]
collection=db["workers"]

res=collection.find_one(worker)
print("current id and salary of document: '%s'"%(res))

# res=collection.update_one()
collection.update_one(worker,{"$set": newsalary},)

print('update succesfull')
updtres=collection.find_one(worker)
print('Updated salary of document : ',updtres)


file.close()
