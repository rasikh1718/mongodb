
import pymongo
from pymongo import MongoClient
cluster =MongoClient("mongodb+srv://RasikhDB:Rasikh1718*@rasikhdb.x9rflrb.mongodb.net/?retryWrites=true&w=majority")

db = cluster["office"]
collection=db["workers"]

post={"_id":102,"empnm":"abdul","dept":"IT","post":"devoloper","city":"amravati","salary":35000,"mobile":"9284881195","email":"abdul@gmail"}

collection.insert_one(post)

print('sucessfully inserted')