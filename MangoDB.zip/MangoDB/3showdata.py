

from pymongo import MongoClient

constr="mongodb+srv://RasikhDB:Rasikh1718*@rasikhdb.x9rflrb.mongodb.net/?retryWrites=true&w=majority"

client=MongoClient(constr)

db=client["office"]
coll=db["workers"]

for doc in coll.find():
    print(doc)
    print()