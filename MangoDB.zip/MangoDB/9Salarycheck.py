import json
from pymongo import MongoClient


constr="mongodb+srv://RasikhDB:Rasikh1718*@rasikhdb.x9rflrb.mongodb.net/?retryWrites=true&w=majority"

client=MongoClient(constr)

db=client["office"]
coll=db["workers"]
try:
    sl = int(input('Enter the salary : '))
    print()

    if coll.find({'salary' : {'$gt' : sl}}):
        for doc in coll.find({'salary' : {'$gt' : sl}}):
            print(json.dumps(doc, sort_keys = False, indent = 2))
            print()

    else:
        print('Employees not found for salary greater than %d\n' %sl)
except:
       print('Wrong input\n')