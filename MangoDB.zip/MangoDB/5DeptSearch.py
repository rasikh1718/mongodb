# Write a program take department as an input and display documents 
# of all workers of the department

import json
dept=(input('Enter Department :'))

worker={
    "dept":dept
}   

file=open("worker.json","w")
json.dump(worker,file)

from pymongo import MongoClient

constr="mongodb+srv://RasikhDB:Rasikh1718*@rasikhdb.x9rflrb.mongodb.net/?retryWrites=true&w=majority"

client=MongoClient(constr)
db=client["office"]
collection=db["workers"]

for doc in collection.find(worker):  
    print(doc)
file.close()
print("successfull...")