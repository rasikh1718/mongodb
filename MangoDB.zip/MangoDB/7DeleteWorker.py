'''Write a program to accept ID, fetch the document from collection, 
copy it in another collection "exworkers" and delete the document from 
the "workers" collection'''

import json
id=int(input('Enter id :'))

worker={
    "_id":id
}   

file=open("worker.json","w")
json.dump(worker,file)

from pymongo import MongoClient

constr="mongodb+srv://RasikhDB:Rasikh1718*@rasikhdb.x9rflrb.mongodb.net/?retryWrites=true&w=majority"

client=MongoClient(constr)
db=client["office"]
coll1=db["workers"]
coll2 = db["Exworkers"]
res=coll1.find_one(worker)
print(res)

if res:
    print(json.dumps(res, sort_keys = False, indent = 2))
    coll2.insert_one(res)
    coll1.delete_one(worker)
    print('\nEmployee is removed from Workers collection\n')

else:
    print('Employee not found\n')
file.close()

