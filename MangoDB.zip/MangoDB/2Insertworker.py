


import json
import pymongo
from pymongo import MongoClient
cluster =MongoClient("mongodb+srv://RasikhDB:Rasikh1718*@rasikhdb.x9rflrb.mongodb.net/?retryWrites=true&w=majority")

db = cluster["office"]
collection=db["workers"]

file=open('worker.json','r')
post=json.load(file)

collection.insert_one(post)
file.close()
print('sucessfully inserted')