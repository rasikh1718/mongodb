
import json

id=int(input('Enter id :'))
empnm=input('enter name :')
dept=input('enter dept :')
post=input('enter post :')
city=input('enter city :')
salary=int(input('enter salary :'))
mobile=input('Eneter mobile no: ')
email=input('enter email :')


worker={
    "_id":id,
    "empnm":empnm,
    "dept":dept,
    "post":post,
    "city":city,
    "salary":salary,
    "mobile":mobile,
    "email":email
}
file=open("worker.json","w")
json.dump(worker,file)
file.close()

import pymongo
from pymongo import MongoClient
cluster =MongoClient("mongodb+srv://RasikhDB:Rasikh1718*@rasikhdb.x9rflrb.mongodb.net/?retryWrites=true&w=majority")

db = cluster["office"]
collection=db["workers"]

file=open('worker.json','r')
post=json.load(file)

collection.insert_one(post)
file.close()
print(' Worker data sucessfully inserted')

