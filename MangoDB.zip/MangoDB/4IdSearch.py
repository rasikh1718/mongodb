
import json
id=int(input('Enter id :'))

worker={
    "_id":id
}   

file=open("worker.json","w")
json.dump(worker,file)

from pymongo import MongoClient

constr="mongodb+srv://RasikhDB:Rasikh1718*@rasikhdb.x9rflrb.mongodb.net/?retryWrites=true&w=majority"

client=MongoClient(constr)
db=client["office"]
collection=db["workers"]
res=collection.find_one(worker)
print(res)
file.close()
print("successfull...")
         
    