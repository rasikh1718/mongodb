'''Write a program to accept ID, city and department. Update the 
document with new city and department of the worker.'''


import json
from typing import Set
from matplotlib import collections
id=int(input('Enter id :'))
nwcity=input("Enter the new city : ")
nwdept=input("Enter new departemnt of worker :")
worker={"_id":id}

nwctdp= {"city":nwcity , "dept": nwdept}



file=open("worker.json","w")
json.dump(worker,file)

from pymongo import MongoClient

constr="mongodb+srv://RasikhDB:Rasikh1718*@rasikhdb.x9rflrb.mongodb.net/?retryWrites=true&w=majority"

client=MongoClient(constr)

db=client["office"]
collection=db["workers"]

res=collection.find_one(worker)
print("current id , city and department of  worker of document: '%s'"%(res))

collection.update_many( worker,{"$set": nwctdp},)
print('update succesfull')
updtres=collection.find_one(worker)
print('New city and department of worker : ',updtres)


file.close()
